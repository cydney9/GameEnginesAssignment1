using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//Added for Lab 8
using TMPro;
using DG.Tweening;
public class Item : MonoBehaviour
{

    //What the player has currently
    private string possesion;
    private int points;

    //items
    public GameObject red;
    public GameObject blue;
    public GameObject green;

    //holes
    public GameObject redHole;
    public GameObject blueHole;
    public GameObject greenHole;

    //ui
    public Text collect;

    //Added for lab 8
    [SerializeField] private TextMeshProUGUI messageDisplay;
    [SerializeField] private float tweenTime;
    private Queue<string> messages = new Queue<string>();
    private bool winner = false; 
    
    void Start()
    {
        //What the player has
        possesion = "Nothing";
        points = 0;
        //UI Text
        collect.text = "Has Nothing";

 

    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        //This is For collecting the item
        if (collision.gameObject.gameObject == red && possesion == "Nothing")
        {
            possesion = "Red";
            Destroy(red);
            Debug.Log("Collected Red");
            collect.text = "Has " + possesion + " Item";
         
        }
        else if (collision.gameObject.gameObject == green && possesion == "Nothing")
        {
            possesion = "Green";
            Destroy(green);
            Debug.Log("Collected Green");
            collect.text = "Has " + possesion + " Item";
        }
        else if (collision.gameObject.gameObject == blue && possesion == "Nothing") 
        {
            possesion = "Blue";
            Destroy(blue);
            Debug.Log("Collected Blue");
            collect.text = "Has " + possesion + " Item";
        }
        //For dropping into holes
        else if (collision.gameObject.gameObject == redHole && possesion == "Red")
        {
            possesion = "Nothing";
            Destroy(redHole);
            Debug.Log("Dropped Red");
            points += 1;
            Debug.Log(points);
            collect.text = "Has " + possesion;
        }
        else if (collision.gameObject.gameObject == greenHole && possesion == "Green")
        {
            possesion = "Nothing";
            Destroy(greenHole);
            Debug.Log("Dropped Green");
            points += 1;
            Debug.Log(points);
            collect.text = "Has " + possesion;
        }
        else if (collision.gameObject.gameObject == blueHole && possesion == "Blue")
        {
            possesion = "Nothing";
            Destroy(blueHole);
            Debug.Log("Dropped Blue");
            points += 1;
            Debug.Log(points);
            collect.text = "Has " + possesion;
        }
    }

    //For Lab 8

    private void CheckQueue()
    { 
        if (!DOTween.IsTweening(messageDisplay.rectTransform))
        { 
            if (messages.Count > 0) 
            { 
                DisplayMessageAnimate(messages.Dequeue());
            }
        }
    }
 
    private void DisplayMessageAnimate(string obj) 
    { messageDisplay.text = obj; 
        messageDisplay.rectTransform.localScale = new Vector3(1.7f, 1.7f, 1.7f); 
        messageDisplay.rectTransform.DOScale(0, tweenTime); 
    }
    private void winning(string obj)
    {
        if (winner == true) {
            messageDisplay.text = obj;
        }
    }
        private void Update()
    {
        if (points == 3) 
        {
            Debug.Log("You Win");
            winner = true;
            //messageDisplay.text = "You Win";
            Time.timeScale = 0; //pause
        }


    }

}
